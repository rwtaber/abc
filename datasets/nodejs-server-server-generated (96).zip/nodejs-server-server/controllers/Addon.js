'use strict';

var url = require('url');

var Addon = require('./AddonService');

module.exports.getAllAddons = function getAllAddons (req, res, next) {
  Addon.getAllAddons(req.swagger.params, res, next);
};
