'use strict';

var url = require('url');

var Monitor = require('./MonitorService');

module.exports.getMonitor = function getMonitor (req, res, next) {
  Monitor.getMonitor(req.swagger.params, res, next);
};
