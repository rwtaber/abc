'use strict';

var url = require('url');

var Project = require('./ProjectService');

module.exports.cleanupProject = function cleanupProject (req, res, next) {
  Project.cleanupProject(req.swagger.params, res, next);
};

module.exports.createProject = function createProject (req, res, next) {
  Project.createProject(req.swagger.params, res, next);
};

module.exports.deleteProject = function deleteProject (req, res, next) {
  Project.deleteProject(req.swagger.params, res, next);
};

module.exports.exportProject = function exportProject (req, res, next) {
  Project.exportProject(req.swagger.params, res, next);
};

module.exports.getGitStatus = function getGitStatus (req, res, next) {
  Project.getGitStatus(req.swagger.params, res, next);
};

module.exports.getProjectDetails = function getProjectDetails (req, res, next) {
  Project.getProjectDetails(req.swagger.params, res, next);
};

module.exports.getProjectStatus = function getProjectStatus (req, res, next) {
  Project.getProjectStatus(req.swagger.params, res, next);
};

module.exports.getProjects = function getProjects (req, res, next) {
  Project.getProjects(req.swagger.params, res, next);
};

module.exports.importFromGHE = function importFromGHE (req, res, next) {
  Project.importFromGHE(req.swagger.params, res, next);
};

module.exports.importProject = function importProject (req, res, next) {
  Project.importProject(req.swagger.params, res, next);
};

module.exports.initializeUserEnvironment = function initializeUserEnvironment (req, res, next) {
  Project.initializeUserEnvironment(req.swagger.params, res, next);
};

module.exports.joinProject = function joinProject (req, res, next) {
  Project.joinProject(req.swagger.params, res, next);
};

module.exports.leaveProject = function leaveProject (req, res, next) {
  Project.leaveProject(req.swagger.params, res, next);
};

module.exports.listDirContents = function listDirContents (req, res, next) {
  Project.listDirContents(req.swagger.params, res, next);
};

module.exports.pullChanges = function pullChanges (req, res, next) {
  Project.pullChanges(req.swagger.params, res, next);
};

module.exports.renameProject = function renameProject (req, res, next) {
  Project.renameProject(req.swagger.params, res, next);
};

module.exports.resetProject = function resetProject (req, res, next) {
  Project.resetProject(req.swagger.params, res, next);
};

module.exports.saveAllChanges = function saveAllChanges (req, res, next) {
  Project.saveAllChanges(req.swagger.params, res, next);
};
