'use strict';

var url = require('url');

var Members = require('./MembersService');

module.exports.addMembers = function addMembers (req, res, next) {
  Members.addMembers(req.swagger.params, res, next);
};

module.exports.deleteMember = function deleteMember (req, res, next) {
  Members.deleteMember(req.swagger.params, res, next);
};

module.exports.deleteSetOfMembers = function deleteSetOfMembers (req, res, next) {
  Members.deleteSetOfMembers(req.swagger.params, res, next);
};

module.exports.getMemberRole = function getMemberRole (req, res, next) {
  Members.getMemberRole(req.swagger.params, res, next);
};

module.exports.getMembers = function getMembers (req, res, next) {
  Members.getMembers(req.swagger.params, res, next);
};

module.exports.updateMember = function updateMember (req, res, next) {
  Members.updateMember(req.swagger.params, res, next);
};
