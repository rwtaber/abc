'use strict';

exports.deleteNotebook = function(args, res, next) {
  /**
   * Deletes a notebook.
   * Only zeppelin notebooks supported currently. Zeppelin loads notebooks metadata in memory as the container is started. Therefore, after modifying notebooks metadata on the filesystem, we need to issue an API call to the zeppelin container to reload the metadata from the filesystem.
   *
   * name String Project Name
   * component String Component Name
   * nbPath String Absolute path. example: /2CQQHUFXK/note.json
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.renameNotebook = function(args, res, next) {
  /**
   * Renames a notebook.
   * Only zeppelin notebooks supported currently. Zeppelin loads notebooks metadata in memory as the container is started. Therefore, after modifying notebooks metadata on the filesystem, we need to issue an API call to the zeppelin container to reload the metadata from the filesystem.
   *
   * name String Project Name
   * component String Component Name
   * nbPath String Absolute path. example: /2CQQHUFXK/note.json
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * body Body_8  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

