'use strict';

exports.deleteContainer = function(args, res, next) {
  /**
   * Delete a container
   * delete a container given the projectName, uid and component to be started.
   *
   * name String Project Name
   * component String Component Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns containersSuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "success" : true,
  "description" : "aeiou",
  "object" : {
    "uid" : "aeiou",
    "projectId" : "aeiou"
  }
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getAllContainerEnvs = function(args, res, next) {
  /**
   * Get a list of all runtime environments used for a project and container type
   * Get a list of all runtime environments that can be used by a user for a project and a container type
   *
   * name String Project Name
   * component String Component, could be jupyter, zeppelin, or rstudio
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns listContainerEnvsSuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "result" : [ {
    "lastUpdated" : 0,
    "displayName" : "aeiou",
    "resources" : {
      "duration" : {
        "units" : "aeiou",
        "value" : 5
      },
      "memory" : {
        "request" : 5
      },
      "cpu" : {
        "request" : 6
      },
      "gpu" : {
        "request" : 1
      }
    },
    "definition" : "aeiou",
    "envId" : "aeiou"
  } ],
  "success" : true,
  "description" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getAllContainers = function(args, res, next) {
  /**
   * Get a list of all containers
   * Get a list of all containers given uid
   *
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns containersList
   **/
  var examples = {};
  examples['application/json'] = {
  "result" : [ {
    "imageName" : "aeiou",
    "cores" : 6,
    "description" : "aeiou",
    "startTime" : 0,
    "type" : "aeiou",
    "projectName" : "aeiou",
    "status" : "aeiou",
    "gbMemory" : 1
  } ],
  "success" : true,
  "description" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getContainers = function(args, res, next) {
  /**
   * Get a list of containers
   * Get a list of containers given the projectName and uid
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns containersList
   **/
  var examples = {};
  examples['application/json'] = {
  "result" : [ {
    "imageName" : "aeiou",
    "cores" : 6,
    "description" : "aeiou",
    "startTime" : 0,
    "type" : "aeiou",
    "projectName" : "aeiou",
    "status" : "aeiou",
    "gbMemory" : 1
  } ],
  "success" : true,
  "description" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getResourcesInfo = function(args, res, next) {
  /**
   * Get cpu and memory resources information from nodes and runtimes of a user
   * Get cpu and memory resources information from nodes and runtimes of a user
   *
   * name String Project Name
   * component String Component, could be jupyter, zeppelin, or rstudio
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns getResourcesInfoSuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "result" : {
    "otherRuntimesMemory" : 1,
    "maxCpuCores" : 0,
    "maxMemory" : 6.0274563
  },
  "success" : true,
  "description" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.startContainer = function(args, res, next) {
  /**
   * Start a container
   * Start a container given the projectName, uid and component to be started.
   *
   * name String Project Name
   * component String Component Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns containersSuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "success" : true,
  "description" : "aeiou",
  "object" : {
    "uid" : "aeiou",
    "projectId" : "aeiou"
  }
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.updateContainer = function(args, res, next) {
  /**
   * Update a container's environment
   * Update a continer's environment.
   *
   * name String Project Name
   * component String Component, could be jupyter, zeppelin, or rstudio
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * body RuntimeEnvironment  (optional)
   * returns containersSuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "success" : true,
  "description" : "aeiou",
  "object" : {
    "uid" : "aeiou",
    "projectId" : "aeiou"
  }
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.updateRuntimeEnv = function(args, res, next) {
  /**
   * Update a runtime environment used for a project
   * Update a runtime environment used for a project and a container type
   *
   * name String Project Name
   * environment RuntimeEnvironment 
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns updateRuntimeEnvSuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "result" : {
    "lastUpdated" : 0,
    "displayName" : "aeiou",
    "resources" : {
      "duration" : {
        "units" : "aeiou",
        "value" : 5
      },
      "memory" : {
        "request" : 5
      },
      "cpu" : {
        "request" : 6
      },
      "gpu" : {
        "request" : 1
      }
    },
    "definition" : "aeiou",
    "envId" : "aeiou"
  },
  "success" : true,
  "description" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

