'use strict';

var url = require('url');

var Users = require('./UsersService');

module.exports.deleteProfilePhoto = function deleteProfilePhoto (req, res, next) {
  Users.deleteProfilePhoto(req.swagger.params, res, next);
};

module.exports.getCurrentUserInfo = function getCurrentUserInfo (req, res, next) {
  Users.getCurrentUserInfo(req.swagger.params, res, next);
};

module.exports.getDSXUsers = function getDSXUsers (req, res, next) {
  Users.getDSXUsers(req.swagger.params, res, next);
};

module.exports.getUserProfilePhoto = function getUserProfilePhoto (req, res, next) {
  Users.getUserProfilePhoto(req.swagger.params, res, next);
};

module.exports.uploadProfilePhoto = function uploadProfilePhoto (req, res, next) {
  Users.uploadProfilePhoto(req.swagger.params, res, next);
};
