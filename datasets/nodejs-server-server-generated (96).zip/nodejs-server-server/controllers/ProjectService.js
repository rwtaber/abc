'use strict';

exports.cleanupProject = function(args, res, next) {
  /**
   * Cleanup project
   * Removes the working copy of the project from local workspace
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.createProject = function(args, res, next) {
  /**
   * Creates a new project
   * Creates a new project that is associated with a git repository
   *
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * projectType String Type of project (optional)
   * body Body  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.deleteProject = function(args, res, next) {
  /**
   * Delete project
   * Deletes a project from local and remote space
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * projectType String Type of project (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.exportProject = function(args, res, next) {
  /**
   * Exports a  project
   * Exports an existing Project (note - Swagger UI corrupts the downloaded zip file)
   *
   * types String <div class='ibm-title'>Values: types</div><ul class='ibm-description'><li>targz</li><li>zip</li></ul>
   * name String This is the name of your project
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns File
   **/
  var examples = {};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getGitStatus = function(args, res, next) {
  /**
   * Check for uncommitted changes or unpulled changes
   * Check for uncommitted changes or ones that are yet to be pulled.
   *
   * projectName String Project Name
   * jwtAuthUserPayload String Supplied by proxy. (optional)
   * returns ProjectStatus
   **/
  var examples = {};
  examples['application/json'] = {
  "canCommit" : true
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getProjectDetails = function(args, res, next) {
  /**
   * Get project info
   * Gets metadata about the project
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy. (optional)
   * returns ProjectDetails
   **/
  var examples = {};
  examples['application/json'] = {
  "owner" : "aeiou",
  "dateCreated" : "aeiou",
  "description" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getProjectStatus = function(args, res, next) {
  /**
   * Check for uncommitted changes or unpulled changes
   * Check for uncommitted changes or ones that are yet to be pulled.
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy. (optional)
   * gitAction String Type of git action (optional)
   * returns ProjectStatus
   **/
  var examples = {};
  examples['application/json'] = {
  "canCommit" : true
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getProjects = function(args, res, next) {
  /**
   * Get projects
   * Directory list of all repos
   *
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * projectType String <div>Values:</div><ul><span class='ibm-default'></span></li><li>library</li><li>restricted</li></ul> (optional)
   * includeCommitInfo Boolean Set to true to include can-commit and user-role information in addition to project-name and last-modified attributes. (optional)
   * limit String  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.importFromGHE = function(args, res, next) {
  /**
   * Import a project from GH
   * Import a project from GH
   *
   * repository String 
   * tokenName String 
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.importProject = function(args, res, next) {
  /**
   * Imports a new project
   * Imports an existing project that is associated with a git repository
   *
   * name String File Name.
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * upfile File The file to upload (optional)
   * note String Description of file contents. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.initializeUserEnvironment = function(args, res, next) {
  /**
   * Initialize User Environment
   * Creates a new project that is associated with a git repository
   *
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.joinProject = function(args, res, next) {
  /**
   * Join an existing project
   * Joins a project by cloning master repo into user's home dir
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.leaveProject = function(args, res, next) {
  /**
   * Leave project
   * Removes the project from user's local workspace and the user is no longer a member of the project
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.listDirContents = function(args, res, next) {
  /**
   * Lists dir's contents based on provided path. Query parametr listPublished
   * Lists dir's contents based on provided path.
   *
   * projectName String The project name
   * dirPath String Path to directory. Absolute to the user workspace directory.
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * projectType String  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.pullChanges = function(args, res, next) {
  /**
   * Pull new changes
   * Pulls changes for a project from remote workspace into local workspace
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.renameProject = function(args, res, next) {
  /**
   * Rename project
   * Rename a project
   *
   * name String Existing project name
   * new_name String New project name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * projectType String Type of project (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.resetProject = function(args, res, next) {
  /**
   * Reset project
   * Removes the existing copy and clones a new copy of the project in the local workspace
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.saveAllChanges = function(args, res, next) {
  /**
   * Push all local changes
   * Tracks all local changes within the project and pushes them to origin/master in remote repository
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * body Body_1  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

