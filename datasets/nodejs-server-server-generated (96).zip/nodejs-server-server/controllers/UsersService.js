'use strict';

exports.deleteProfilePhoto = function(args, res, next) {
  /**
   * Deletes the user's profile photo
   *
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getCurrentUserInfo = function(args, res, next) {
  /**
   * Get information about the current user
   *
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getDSXUsers = function(args, res, next) {
  /**
   * Get all DSX users
   * Returns a list of all users registered on DSX
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getUserProfilePhoto = function(args, res, next) {
  /**
   * Get the user's profile picture
   *
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.uploadProfilePhoto = function(args, res, next) {
  /**
   * Uploads the user's profile photo
   *
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * file File The file to upload (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

