'use strict';

exports.addToken = function(args, res, next) {
  /**
   * Adds a Github token to DSX.
   * Token is used to access Github from DSX. Bitbucket/Gitlab will be supported in a future release.
   *
   * tokenValue String Token to be used when performing an action on the platform
   * tokenName String Name of the token
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * body Body_7  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.deleteToken = function(args, res, next) {
  /**
   * Deletes a Github token from DSX
   * Bitbucket/Gitlab will be supported in a future release.
   *
   * tokenName String Name of the token
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getTokens = function(args, res, next) {
  /**
   * Checks if Github tokens exist for this user.
   * Returns not found if token does not exist.
   *
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * no response value expected for this operation
   **/
  res.end();
}

