'use strict';

var url = require('url');

var Notebooks = require('./NotebooksService');

module.exports.deleteNotebook = function deleteNotebook (req, res, next) {
  Notebooks.deleteNotebook(req.swagger.params, res, next);
};

module.exports.renameNotebook = function renameNotebook (req, res, next) {
  Notebooks.renameNotebook(req.swagger.params, res, next);
};
