'use strict';

var url = require('url');

var Github = require('./GithubService');

module.exports.addToken = function addToken (req, res, next) {
  Github.addToken(req.swagger.params, res, next);
};

module.exports.deleteToken = function deleteToken (req, res, next) {
  Github.deleteToken(req.swagger.params, res, next);
};

module.exports.getTokens = function getTokens (req, res, next) {
  Github.getTokens(req.swagger.params, res, next);
};
