'use strict';

exports.addFlow = function(args, res, next) {
  /**
   * Adds a flow to the project
   * Adds a flow to the project
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * body Body_4  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.addModel = function(args, res, next) {
  /**
   * Adds a model to the project
   * Adds a model to the project
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * body Body_3  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.deleteFile = function(args, res, next) {
  /**
   * Delete local/remote datasets and scripts (library projects)
   * Delete local/remote datasets and scripts (library projects)
   *
   * projectName String Project Name
   * filePath String Path to file
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * projectType String Type of project (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.deleteModel = function(args, res, next) {
  /**
   * Deletes a model
   * Deletes a model
   *
   * modelId String Model ID
   * type String  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.downloadDataset = function(args, res, next) {
  /**
   * Downloads local dataset from the project
   * Downloads local dataset from the project. Download of remote datasets currently not supported.
   *
   * name String Project Name
   * dataset_name String Dataset Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * projectType String Type of project (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getAsset = function(args, res, next) {
  /**
   * Get an asset for preview
   * Returns the content of the requested asset
   *
   * name String Project Name
   * file String File Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * type String <div class='ibm-title'>Values: types</div><ul class='ibm-description'><li>datasets</li><li>models</li><li>jupyter</li></ul> (optional)
   * projectType String Type of project (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getAssets = function(args, res, next) {
  /**
   * Gets an array of all assets
   * Gets an array of all assets. The response returns an array of objects. Each object contains the asset name, asset type, and last modified date, sorted by last modified date.
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * types List <div class='ibm-title'>Values: types</div><ul class='ibm-description'><li>zeppelin</li><li>jupyter</li><li>localdatasets</li><li>remotedatasets</li><li>rstudio</li><li>models</li><li>datasources</li><li>flows</li><li>scripts</li><li>others (Anything that is not in the directories above.Not to be used in conjunction with the directories above) </li></ul> (optional)
   * filter String Provide a value to filter by. Filter is applied only one of the types (optional)
   * projectType String Project type (optional)
   * limit BigDecimal Number of results to be returned (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getBluemixCredentials = function(args, res, next) {
  /**
   * Get persisted bluemix login credentials
   * Returns metadata as a remember me boolean, bluemix username and pass
   *
   * name String Project Name
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getModels = function(args, res, next) {
  /**
   * Get a list of models
   * Returns models
   *
   * name String Project Name
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getRemoteDatasets = function(args, res, next) {
  /**
   * Gets remote datasets for a particular data source
   * Lists remote datasets and their contents associated with a data source
   *
   * name String Project Name
   * datasourceName String Name of the datasource
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getSampleJSON = function(args, res, next) {
  /**
   * Gets an array of sample jsons
   * Gets an array of all sample JSONS. The response returns an json array of sample jsons.
   *
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * landingPage Boolean Set to true to randomize the sample notebooks for tiles on the landing page. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getSavedModels = function(args, res, next) {
  /**
   * Get a list of saved models
   * Returns saved models
   *
   * name String Project Name
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.postBluemixCredentials = function(args, res, next) {
  /**
   * Post persisted bluemix login creddentials
   * Writes metadata as a remember me boolean, bluemix username and pass to bluemix.json file
   *
   * name String Project Name
   * body Body_6  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.pushToBlueMix = function(args, res, next) {
  /**
   * Push a model to bluemix
   * Returns models
   *
   * bluemixToken String Bluemix token
   * name String Project Name
   * body Body_5  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.uploadFile = function(args, res, next) {
  /**
   * Uploads a file from the file system
   * Uploads a file from  the file system
   *
   * name String Project Name
   * type String File type.
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * file File The file to upload (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

