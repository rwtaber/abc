'use strict';

var url = require('url');

var Assets = require('./AssetsService');

module.exports.addFlow = function addFlow (req, res, next) {
  Assets.addFlow(req.swagger.params, res, next);
};

module.exports.addModel = function addModel (req, res, next) {
  Assets.addModel(req.swagger.params, res, next);
};

module.exports.deleteFile = function deleteFile (req, res, next) {
  Assets.deleteFile(req.swagger.params, res, next);
};

module.exports.deleteModel = function deleteModel (req, res, next) {
  Assets.deleteModel(req.swagger.params, res, next);
};

module.exports.downloadDataset = function downloadDataset (req, res, next) {
  Assets.downloadDataset(req.swagger.params, res, next);
};

module.exports.getAsset = function getAsset (req, res, next) {
  Assets.getAsset(req.swagger.params, res, next);
};

module.exports.getAssets = function getAssets (req, res, next) {
  Assets.getAssets(req.swagger.params, res, next);
};

module.exports.getBluemixCredentials = function getBluemixCredentials (req, res, next) {
  Assets.getBluemixCredentials(req.swagger.params, res, next);
};

module.exports.getModels = function getModels (req, res, next) {
  Assets.getModels(req.swagger.params, res, next);
};

module.exports.getRemoteDatasets = function getRemoteDatasets (req, res, next) {
  Assets.getRemoteDatasets(req.swagger.params, res, next);
};

module.exports.getSampleJSON = function getSampleJSON (req, res, next) {
  Assets.getSampleJSON(req.swagger.params, res, next);
};

module.exports.getSavedModels = function getSavedModels (req, res, next) {
  Assets.getSavedModels(req.swagger.params, res, next);
};

module.exports.postBluemixCredentials = function postBluemixCredentials (req, res, next) {
  Assets.postBluemixCredentials(req.swagger.params, res, next);
};

module.exports.pushToBlueMix = function pushToBlueMix (req, res, next) {
  Assets.pushToBlueMix(req.swagger.params, res, next);
};

module.exports.uploadFile = function uploadFile (req, res, next) {
  Assets.uploadFile(req.swagger.params, res, next);
};
