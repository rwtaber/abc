'use strict';

var url = require('url');

var Container = require('./ContainerService');

module.exports.deleteContainer = function deleteContainer (req, res, next) {
  Container.deleteContainer(req.swagger.params, res, next);
};

module.exports.getAllContainerEnvs = function getAllContainerEnvs (req, res, next) {
  Container.getAllContainerEnvs(req.swagger.params, res, next);
};

module.exports.getAllContainers = function getAllContainers (req, res, next) {
  Container.getAllContainers(req.swagger.params, res, next);
};

module.exports.getContainers = function getContainers (req, res, next) {
  Container.getContainers(req.swagger.params, res, next);
};

module.exports.getResourcesInfo = function getResourcesInfo (req, res, next) {
  Container.getResourcesInfo(req.swagger.params, res, next);
};

module.exports.startContainer = function startContainer (req, res, next) {
  Container.startContainer(req.swagger.params, res, next);
};

module.exports.updateContainer = function updateContainer (req, res, next) {
  Container.updateContainer(req.swagger.params, res, next);
};

module.exports.updateRuntimeEnv = function updateRuntimeEnv (req, res, next) {
  Container.updateRuntimeEnv(req.swagger.params, res, next);
};
