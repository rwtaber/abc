'use strict';

exports.addMembers = function(args, res, next) {
  /**
   * Add members
   * Adds set of users to a project
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * body List  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.deleteMember = function(args, res, next) {
  /**
   * Delete member
   * Delete a member from a project
   *
   * name String Project Name
   * member_uid String Member UID
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.deleteSetOfMembers = function(args, res, next) {
  /**
   * Delete members
   * Deletes a set of members from a project
   *
   * name String Project Name
   * body List [uid1, uid2, ...]
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getMemberRole = function(args, res, next) {
  /**
   * Get member role
   * Get the member's role associated with the project
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getMembers = function(args, res, next) {
  /**
   * Get members
   * Get all collaborators for a particular project
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * limit String  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.updateMember = function(args, res, next) {
  /**
   * Update member
   * Updates the role of a member
   *
   * name String Project Name
   * jwtAuthUserPayload String Supplied by proxy.  Do NOT add your own value. (optional)
   * body Body_2  (optional)
   * returns SuccessResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

